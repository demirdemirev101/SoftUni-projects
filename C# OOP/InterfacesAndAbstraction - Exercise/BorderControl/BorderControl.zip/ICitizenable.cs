﻿namespace BorderControl
{
    using System;
    public interface ICitizenable :IBuyer
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string Id { get; set; }
        public string Birthdate { get; set; }
    }
}
