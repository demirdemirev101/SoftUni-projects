﻿namespace BorderControl
{
    public interface IRobotable
    {
        public string Model { get; set; }
        public string Id { get; set; }

    }
}
