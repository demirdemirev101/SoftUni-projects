﻿namespace BorderControl
{
    public interface IBuyer
    {
        public int Food { get; set; }
        public void BuyFood();
    }
}
